local e3 = require'exampleThree'

print (e3.mysin(3.14))
print (e3.idiv(11,3))
  
print (e3.mysin('x'))
print (e3.idiv(11,0))
  